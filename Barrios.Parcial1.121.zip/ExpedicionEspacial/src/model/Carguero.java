package model;

import excepciones.CapacidadNoValidaException;
import interfaces.Explorable;
import interfaces.Mantenible;
import java.time.LocalDate;

public class Carguero extends Nave implements Explorable, Mantenible
{
    private int capacidadCarga;
    
    private static final int CAPACIDAD_MINIMA = 100;
    private static final int CAPACIDAD_MAXIMA = 500;

    public Carguero(int capacidadCarga, String nombre, int capacidadTripulacion, LocalDate anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        comprobarCarga(capacidadCarga);
        this.capacidadCarga = capacidadCarga;
    }

    public void comprobarCarga(int capacidad)
    {
        if(capacidad < CAPACIDAD_MINIMA || capacidad > CAPACIDAD_MAXIMA)
        {
            throw new CapacidadNoValidaException();
        }
    }
    
    @Override
    public String explorar() {
        return "Nave "+toString()+" explorando...";
    }

    @Override
    public String realizarMantenimiento() {
        return "Nave "+toString()+" realizando mantenimiento...";
    }

    @Override
    public String toString() {
        return super.toString()+" Carguero{" + "capacidadCarga=" + capacidadCarga + '}';
    }

}
