package model;
public enum TipoMision
{
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO
}
