package model;

import interfaces.Mantenible;
import java.time.LocalDate;

public class Crucero extends Nave implements Mantenible
{
    private int cantidadPasajeros;

    public Crucero(int cantidadPasajeros, String nombre, int capacidadTripulacion, LocalDate añoLanzamiento) {
        super(nombre, capacidadTripulacion, añoLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public String realizarMantenimiento() {
        return "Nave "+toString()+" realizando mantenimiento...";
    }

    @Override
    public String toString() {
        return super.toString()+" Crucero{" + "cantidadPasajeros=" + cantidadPasajeros + '}';
    }
    
    
    
}
