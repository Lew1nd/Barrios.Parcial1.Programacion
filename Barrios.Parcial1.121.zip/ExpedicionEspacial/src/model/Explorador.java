package model;

import interfaces.Explorable;
import java.time.LocalDate;

public class Explorador extends Nave implements Explorable
{
    TipoMision tipoMision;

    public Explorador(TipoMision tipoMision, String nombre, int capacidadTripulacion, LocalDate anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.tipoMision = tipoMision;
    }

    public boolean esTipoMision(TipoMision tipo){
        return this.tipoMision == tipo;
    }

    @Override
    public String explorar() {
        return "Nave "+toString()+" explorando...";
    }

    @Override
    public String toString() {
        return super.toString()+" Explorador{" + "tipoMision=" + tipoMision + '}';
    }
    
    
}
