package model;

import excepciones.MismaNaveException;
import interfaces.Explorable;
import java.util.ArrayList;
import java.util.List;
public class Agencia 
{
    private String nombre;
    private List<Nave> navesEspaciales = new ArrayList<>();

    public Agencia(String nombre) {
        this.nombre = nombre;
    }
   
    public void agregarNave(Nave nave)
    {
        if(nave != null){
            mismaNave(nave);
            navesEspaciales.add(nave);
        }
    }
    
    public void mostrarNaves()
    {   
        for (Nave nave : navesEspaciales) {
            System.out.println(nave.toString());
        }
    }
    
    public void iniciarExploracion()
    {
        for (Nave nave : navesEspaciales) 
        {
            if(nave instanceof Explorable exploradores)
            {
                System.out.println(exploradores.explorar());
            }
           
            if (nave instanceof Carguero carguero)
            {
                System.out.println("La nave "+carguero.toString()+" no puede realizar tareas de exploracion.");
            }
        }
    }
    
    public ArrayList<Explorador> filtrarPorTipoMision(TipoMision tipo)
    {
        ArrayList<Explorador> navePorTipo = new ArrayList<>();
        for(Nave nave: navesEspaciales)
        {
            if(nave instanceof Explorador explorador)
            {
                if(explorador.esTipoMision(tipo))
                {
                    navePorTipo.add(explorador);
                }
            }
        }
        return navePorTipo; 
    }
    
    public void mismaNave(Nave nuevaNave)
    {
        if(!navesEspaciales.isEmpty()){
            for(Nave nave : navesEspaciales){
                if(nave.equals(nuevaNave)){
                    throw new MismaNaveException();
                }
            }
        }
    }
    
}
