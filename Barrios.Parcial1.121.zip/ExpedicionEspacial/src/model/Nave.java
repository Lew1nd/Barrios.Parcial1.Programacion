package model;

import excepciones.AñoLanzamientoInvalidoException;
import java.time.LocalDate;
import java.util.Objects;

public abstract class Nave
{
    private String nombre;
    private int capacidadTripulacion;
    private LocalDate anioLanzamiento;

    public Nave(String nombre, int capacidadTripulacion, LocalDate anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        comprobarAnioLanzamiento(anioLanzamiento);
        this.anioLanzamiento = anioLanzamiento;
    }
    
    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof Nave nave))
        {
            return false;
        }
        
        return this.nombre.equals(nave.nombre) && this.anioLanzamiento.equals(nave.anioLanzamiento);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre, anioLanzamiento);
    }
    
    public void comprobarAnioLanzamiento(LocalDate anio)
    {
        if (anio.isAfter(LocalDate.now())) {
            throw new AñoLanzamientoInvalidoException();
        }
    }

    @Override
    public String toString() {
        return "Nave{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento + '}';
    }
    
}
