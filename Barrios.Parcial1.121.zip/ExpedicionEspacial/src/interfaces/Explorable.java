package interfaces;
public interface Explorable 
{
    String explorar();
    
}
