package interfaces;
public interface Mantenible 
{
    String realizarMantenimiento();
}
