package expedicionespacial;

import java.time.LocalDate;
import java.util.ArrayList;
import model.Agencia;
import model.Carguero;
import model.Explorador;
import model.Crucero;
import model.TipoMision;
import java.util.List;

public class ExpedicionEspacial
{
    public static void main(String[] args)
    {
        Agencia agencia = new Agencia("Estrella de hades");
        hardExpedicionEspacial(agencia);
    }
    
    public static void hardExpedicionEspacial(Agencia agencia)
    {
        List<Explorador> exploradores = new ArrayList<>();
        Carguero car1 = new Carguero(300, "Galactica", 1000, LocalDate.of(2012, 5, 6));
        
        
        //Carguero car2 = new Carguero(300, "Transporte", 1000, LocalDate.of(999999, 5, 6));//nave con año de lanzamiento no valido
        //Carguero car3 = new Carguero(999999, "Transporte2", 1000, LocalDate.of(2012, 5, 6));//nave con capacidad superada
        
        Explorador ex1 = new Explorador(TipoMision.CARTOGRAFIA, "Explorer", 150, LocalDate.of(2010, 10, 1));
        Explorador ex2 = new Explorador(TipoMision.CONTACTO, "Wanderer", 200, LocalDate.of(2022, 6, 5));
        Explorador ex3 = new Explorador(TipoMision.CARTOGRAFIA, "Traveler", 120, LocalDate.of(2020, 1, 1));
        
        Crucero cru1 = new Crucero(100, "Laffey", 5, LocalDate.of(2020, 2, 15));
        
        agencia.agregarNave(car1);
        //agencia.agregarNave(car2);
        //agencia.agregarNave(car1);//Excepcion misma nave
        agencia.agregarNave(ex1);
        agencia.agregarNave(ex2);
        agencia.agregarNave(ex3);
        agencia.agregarNave(cru1);

        //agencia.mostrarNaves();//Muestra todas las naves
        
        //agencia.iniciarExploracion();//Inicia la mision de todas las naves explorables
        
        //Filtra por tipo de mision de Cartografia
        /*
        exploradores = agencia.filtrarPorTipoMision(TipoMision.CARTOGRAFIA);
        for (Explorador explorador : exploradores) {
            System.out.println(explorador.toString());
        }
        */
    }
    
}
