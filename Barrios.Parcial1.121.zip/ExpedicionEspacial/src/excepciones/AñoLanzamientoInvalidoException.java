package excepciones;
public class AñoLanzamientoInvalidoException extends RuntimeException
{
    private static final String MENSAJE = "Año de lanzamiento invalido";
    
    public AñoLanzamientoInvalidoException(){
        this(MENSAJE);
    }
    
    public AñoLanzamientoInvalidoException(String mensaje) {
        super(mensaje);
    }
}
