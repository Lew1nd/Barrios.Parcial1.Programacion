package excepciones;
public class MismaNaveException extends RuntimeException
{
    private static final String MENSAJE = "Esa nave ya está en la lista.";
    
    public MismaNaveException(){
        this(MENSAJE);
    }
    
    public MismaNaveException(String mensaje) {
        super(mensaje);
    }
    
}
