package excepciones;
public class CapacidadNoValidaException extends RuntimeException
{
    private static final String MENSAJE = "Valores de capacidad de carga no validos.";
    
    public CapacidadNoValidaException(){
        this(MENSAJE);
    }
    
    public CapacidadNoValidaException(String mensaje) {
        super(mensaje);
    }
}
